package faculdade.exemplologin;

//https://spring.io/guides/gs/securing-web/

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinhaSecuringWebApplication {
    public static void main(String[] args) throws Throwable {
        SpringApplication.run(MinhaSecuringWebApplication.class, args);
        System.out.printf("Hello and welcome!");
    }
}
