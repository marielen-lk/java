package faculdade.bancodados;

import domain.entity.Cliente;
import domain.repository.ClientesDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@SpringBootApplication
@RestController
//@EntityScan(basePackages = {"domain.entity"})
@ComponentScan (basePackages = {"domain.repository"})


public class VendasApplication {

    @Bean
    public CommandLineRunner init (@Autowired ClientesDAO clientes) {
        return args -> {
            Cliente c = new Cliente("Marielen");
            System.out.println("Salvando Cliente");
            clientes.salvarCliente(c);

            c = new Cliente("Gabriel Sena");
            System.out.println("Salvando Cliente");
            clientes.salvarCliente(c);

            List<Cliente> listaCli = clientes.obterTodos();
            System.out.println("Listando Clientes");
            listaCli.forEach(System.out::println);

//            System.out.println("Atualizando Clientes");
//            listaCli.forEach(cl -> {
//                cl.setNome(cl.getNome() + " Atualizado");
//                clientes.atualizarCliente(cl);
//            });

            System.out.println("Listando Clientes Atualizados");
            listaCli = clientes.obterTodos();
            listaCli.forEach(System.out::println);

            listaCli = clientes.obterClienteByNome("Sena");
            System.out.println("Listando Cliente especifico");
            listaCli.forEach(System.out::println);

//            System.out.println("Removendo um Cliente");
//            listaCli.forEach(cl -> {
//                cl.setId(1);
//                clientes.deletarCliente(cl);
//            });

            listaCli = clientes.obterTodos();
            System.out.println("Listando Clientes pela ultima vez");
            listaCli.forEach(System.out::println);

        };
    }
    public static void main(String[] args) {
        SpringApplication.run (VendasApplication.class,args);
        System.out.println("Alo Mundo sprint Boot. " );
    }
}
