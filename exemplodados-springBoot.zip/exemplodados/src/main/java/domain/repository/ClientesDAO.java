package domain.repository;

import domain.entity.Cliente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class ClientesDAO {
    private static final String SELECT_BY_NOME = "select * from cliente where nome like ? ";
    private static final String INSERT_CLI = "insert into cliente (nome) values (?)";
    private static final String SELECT_ALL = "select * from cliente";
    private static final String UPDATE = "update cliente set nome='(?)' where id=?";
    private static final String DELETE = "delete from nome where id= ?";
    @Autowired
    private JdbcTemplate jdbcConexao;

//    @Autowired
//    private EntityManager entityManager;
//    @Transactional
//    public ClienteJPA salvarClienteJPA(ClienteJPA cliente){
//        entityManager.persist(cliente);
//        return cliente;
//    }

    public Cliente salvarCliente(Cliente cliente) {
        jdbcConexao.update(INSERT_CLI, new Object[]{cliente.getNome()});
        return cliente;
    }

    public List<Cliente> obterTodos() {
        return jdbcConexao.query(SELECT_ALL, new RowMapper<Cliente>() {
            @Override
            public Cliente mapRow(ResultSet rs, int rowNum) throws SQLException {
                Integer idC = rs.getInt("id");
                String nomeC = rs.getString("nome");
                return new Cliente(idC, nomeC);
            }
        });
    }

    public List<Cliente> obterClienteByNome(String nome) {
        return jdbcConexao.query(SELECT_BY_NOME, new
                Object[]{"%" + nome + "%"}, new RowMapper<Cliente>() {
            @Override
            public Cliente mapRow(ResultSet rs, int rowNum) throws SQLException {
                Integer idC = rs.getInt("id");
                String nomeC = rs.getString("nome");
                return new Cliente(idC, nomeC);
            }
        });
    }

    public Cliente atualizarCliente(Cliente cliente) {
        jdbcConexao.update(String.valueOf(UPDATE), new Object[]{
                cliente.getNome(), cliente.getId()});
        return cliente;
    }

    public Cliente deletarCliente(Cliente cliente) {
        jdbcConexao.update(String.valueOf(DELETE), cliente.getId());
        return cliente;

    }
}
